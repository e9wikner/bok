# Komponentinventering

Namnen är de som står som chips i annoteringspanelen i `BokAi flöden v1.dc.html`. Använd dem, eller mappa dem en gång till projektets namn och håll fast vid mappningen.

Allt är inline-stilat i designfilerna. Värden nedan är avsedda, inte ungefärliga.

## Chatten

### TradInlagg/agent
Agentens inlägg. Kolumn med `gap 13`.
- Metarad: mono 11, `letter-spacing 0.08em`, versalt, `#9ca3af`. Format `agenten · 06:41`.
- Text: 15/1.6, max 54ch, `text-wrap: pretty`.
- Valfri `RadLista/i-tråd` och valfria `SparChip` under texten.

### TradInlagg/du
Egen replik, högerställd. Max 74 % bredd, `background #eef0f3`, radius `14 14 4 14`, padding 12/16, text 15/1.55.

### FilInlagg
Bilaga man skickat. Högerställd, `gap 8`. Filkort: `background #eef0f3`, radius 14, padding 12/16, sidikon 30×38 (`border 1px #c7c7cc`, radius 4, vit yta), filnamn 14, filmeta mono 11 `#6b7280` (`218 kB · 1 sida`). Valfri textbubbla under.

### SkriverIndikator
Tre prickar 5×5 (`#a1a1aa`, `#c4c4c8`, `#e0e0e4`, `gap 4`) + text 15 `#52525b` som säger vad som görs: `Postar verifikation A-118…`. Aldrig en anonym spinner. Metarad `AGENTEN` ovanför.

### SparChip
Agentens spår: vad den läste, räknade och gjorde. Mono 12 `#52525b`, `background #f4f4f5`, `border 1px #e5e7eb`, radius 999, padding 4/10, `gap 8`, radbryter. Exempel: `16 händelser lästa`, `kompletteringsflagga satt`.

### RadLista/i-tråd
Rader i ett svar (belopp per anställd, två kvitterade spår, jämförelse). Vit yta, `border 1px #e5e7eb`, radius 12, max-bredd 560, rader padding 11/16 med `border-bottom 1px #f1f1f4`. Vänster: mono 13 `#6b7280` nyckel + text 14. Höger: mono 14 tabular.

### JamforelseRader
Samma komponent som ovan, med nycklarna `var`/`blir` eller `kvitto`/`A-118`. **Båda talen visas alltid.** En ensam ny summa är fel.

### ChattFalt
Radius 12, streckad kant `#c7c7cc`, `background #fbfbfc`, padding 13/16, text 15 `#71717a`, `↵` mono 12 till höger. Ren textinmatning — inga förslagschips.
- Variant `drop`: tar emot filer via drag och släpp, kamera och urklipp. Ingen separat uppladdningssida.

## Kort i tråden

Alla kort: max-bredd 560, radius 12, padding 20/22, kolumn med `gap 14–16`.

### BeslutKort
Agenten avstod och beslutet är öppet.
- Yta `#fffbeb`, kant `#fde68a`.
- Rubrikrad: text 14/500 `#92400e` (`Agenten avstod · behöver ditt beslut`) + mono 12 `#b45309` med källa och datum.
- Kropp: rubrik 15 och belopp mono 15 tabular på samma baslinje, därunder förklaring 14/1.55 `#78716c`.
- Knappar: primär (`#0a0f1a`, vit text, radius 8, padding 9/15, hover `#27272a`), sekundär (vit, `border 1px #d4d4d8`, hover `#f4f4f5`), tertiär (text `#52525b`, ingen kant). Tertiär är valfri.

### GodkannKort
Samma form som `BeslutKort` men rubrikraden säger `Väntar på ditt godkännande`. Används när agenten inte avstått utan bara saknar en underskrift.

### AlternativLista
Agentens förslag. Vit yta, `border 1px #e5e7eb`, radius 12.
- `AlternativRad`: knapp, padding 15/18, `border-bottom 1px #f1f1f4`, hover `#fafafa`. Vänster: ring 16×16 (`border 1px #c7c7cc`, radius 50 %) — **aldrig förvald**. Mitten: titel 15, konto mono 12 `#6b7280`, `RekMarke` vid rekommendation, motivering 14/1.5 `#78716c`. Höger: belopp mono 14.
- `RekMarke`: mono 11 `#15803d`, `background #f0fdf4`, `border 1px #bbf7d0`, radius 999, padding 2/8, text `rekommenderas`.
- Fot: mono 12 `#6b7280`, ett villkor som gäller alla alternativ (`Moms 25 % · 896 kr dras av i båda alternativen`).
- Sista alternativet är alltid en väg ut: `Annat konto`, `Det är ett annat köp`.

### VerifikationsForslag
Utkastet som det blir i böckerna. Vit yta, `border 1px #d4d4d8`, radius 12.
- Rubrikrad: titel 15/500 + mono 12 `#9ca3af`, `border-bottom 1px #f1f1f4`.
- Kolumnrubriker mono 10 versalt `#9ca3af`: Konto / Debet / Kredit, de två högra 92 px högerställda.
- `KonteringsRad`: padding 9/18, konto mono 13 `#6b7280` + namn 14, belopp mono 14 tabular.
- Fot 13/1.55 `#78716c`: underlag och flaggor.
- Knapprad: primär + sekundär + **konsekvensnotis mono 12 `#52525b`** (`låses vid postning`). Notisen är inte metatext — den bär varningen och ska ha läsbar kontrast.
- Konfigurationer: `KonsekvensKort` (kolumner Händelse / Datum / Belopp, fyra rader för lönegodkännandet) och `FakturaForslag` (Rad / Antal / Belopp).

### FelKort
Yta `#fef2f2`, kant `#fecaca`. Rubrik 14/500 `#b91c1c` + mono 12 `#dc2626` med tid och orsak. Text 14/1.55 `#7f1d1d` som säger orsak **och** konsekvens för bokföringen. Knappar: `Försök igen` primär (samma utkast-id), `Visa vad som hände` sekundär.

## Vyn

### VyHeaderStatus
Vytitel 17/500 `letter-spacing -0.01em` + status mono 12 i lägets färg, `border-bottom 1px #f1f1f4`, padding 20/24/14. Samma sträng visas i headern, från samma fält.

### VyBanner
Radius 10, padding 12/14, text 13/1.5. Fyra toner: varning, neutral (`#fafafa`/`#e5e7eb`/`#3f3f46`), fel, klart. En banner åt gången, och bara när den säger något som raderna inte redan säger.

### VySektion
Rubrik mono 10 versalt `#9ca3af`, padding 20/0/6. Tom sektion visas inte alls.

### VyRad
Padding 9/8, `margin 0 -8`, radius 6, `border-bottom 1px #f4f4f5`. Vänster: titel 14 + metarad mono 11. Höger: mono 14 tabular.
Varianter via meta- och radfärg:
- `normal` — meta `#9ca3af`.
- `saknar` / `vantar` — meta `#b45309`, eller `#dc2626` när något är förfallet eller gammalt.
- `pagaende` — text och belopp `#9ca3af`, yta `#fafafa`, meta `A-118 · postas…`.
- `ny` — yta `#f0fdf4`, meta `#15803d`. **Markeringen är kortvarig**, annars färgas listan över tiden.
- `fel` — meta `#dc2626`, raden ligger kvar i väntar-sektionen.
- `paverkad` — meta `#b45309`, används när ett beslut skulle ändra raden men inget gjorts ännu.

## Ram och navigering

### SidTabbar
Bred skärm, från ungefär 900 px. Min-height 44, padding 8/14, radius 9, `gap 4`. Aktiv `background #f4f4f5` / `color #0a0f1a`, inaktiv transparent / `#52525b`, hover `#f4f4f5`. Statusprick 6×6: `#f59e0b` när något väntar, `#d4d4d8` annars.

### SidVaeljare
Smal skärm. Sidtiteln är knappen: titel 15/500 + metarad mono 11 i sidans statusfärg + `▼`. Listan fälls ut direkt under headern (desktop: `width 430`, radius 12, skugga `0 14px 36px rgba(10,15,26,0.16)`; mobil: `left 8 right 8`, radius `0 0 14 14`, med överlägg `rgba(10,15,26,0.28)` över innehållet). Rader min-height 44 (mobil 52) med titel, metarad och bock på aktiv sida.

### PrickNav
Vyer inom sidan. Prickar 7 px, aktiv 20×7, radius 999, aktiv `#0a0f1a`, inaktiv `#d4d4d8`, `gap 9`, i en pillerram `border 1px #e5e7eb`. Riktiga knappar med `aria-label` för vyns namn. Speglar `scroll-snap`-positionen.

### ChattList (mobil)
Knapp min-height 50, padding 11/16: `Chatt` 14/500 + vyns namn 14 `#9ca3af` + märke + `▼`/`▲`. Märket visar väntande beslut även när chatten är minimerad (mono 11 i väntar-färgerna). Uppfälld: tråd 260 px med egen skroll + `ChattFalt`.

### AgentStatus
Prick 7×7 + text 13. Tre lägen: `Agenten arbetar` (`#16a34a` / `#15803d`), `Agenten postar` (`#2563d9` / `#1b49a3`), `Agenten pausad` (`#dc2626` / `#b91c1c`). Pausad ska visas så länge den är pausad, inte bara i felinlägget.
