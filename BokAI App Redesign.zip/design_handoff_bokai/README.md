# Handoff: BokAi agent-first redesign

## Översikt

BokAi är en bokföringstjänst där en agent gör löpande bokföring och människan beslutar där agenten avstår. Redesignen flyttar gränssnittet från formulär och listor till **en chatt per vy**: agenten skriver vad den gjort, lägger fram sina förslag och väntar på beslut på samma plats som siffrorna visas.

Paketet innehåller två designfiler och tre dokument:

| Fil | Innehåll |
| --- | --- |
| `BokAi redesign v10.dc.html` | Informationsarkitektur och skärmar: tre sidor, sju vyer, desktop och mobil |
| `BokAi flöden v1.dc.html` | Fyra skrivflöden steg för steg, med annoteringar per steg |
| `README.md` | Den här filen: skärmar, mått, tillstånd, tokens |
| `komponenter.md` | Komponentinventering med namn, varianter, mått och tillstånd |
| `datakontrakt.md` | Vilka endpoints som finns i repot och vad som måste byggas |
| `skarmbilder/` | 26 bilder: varje flödessteg och v10:s sidor, desktop och mobil |

Skärmbilderna är tagna med annoteringspanelen och dokumentationskromet dolt, så de visar bara gränssnittet. De är nedskalade — designfilerna är källan för mått och färg.

| Serie | Innehåll |
| --- | --- |
| `flode1-*` | Beslutskort: väntar, förslag, bekräfta, postar, postad och låst, fel vid postning |
| `flode2-*` | Löneunderlag: klart, per anställd, godkänn, godkänt, ändring efteråt |
| `flode3-*` | Kundfaktura: beställning i chatten, förslag, skickar, skickad och bokförd |
| `flode4-*` | Underlag: agenten ber, filen läses, matchning, kopplat |
| `v10-desktop-*` | Böcker (balansräkning, verifikationer), sidväljaren utfälld, Fakturering, Bokslut |
| `v10-mobil-*` | Vy och chatt samtidigt: chatten öppen och minimerad |

## Om designfilerna

Filerna är **designreferenser skrivna i HTML** — prototyper som visar avsett utseende och beteende. De är inte produktionskod att kopiera. Uppgiften är att återskapa designen i en ny frontend, med ramverk och bibliotek valda för projektet. `support.js` behövs bara för att öppna filerna i en webbläsare.

Öppna dem och klicka igenom: flödesfilen är interaktiv, och annoteringspanelen till höger säger för varje steg vad systemet gör, vilka kanter som finns och vilka komponenter steget består av.

**Dokumentationskrom som inte ska byggas:** annoteringspanelen till höger om ramen, steglistan, raden "Flöde på sidan" i ramens fot och stegräknaren. De finns för att beskriva designen. Ramen 1180×860 är en ritduk, inte ett fönstermått.

## Fidelity

**Hi-fi.** Färger, typografi, mått och tillstånd är avsedda värden och ska återskapas exakt. Copy i designen är skriven på svenska och är avsedd produkttext, inte platshållare — tonen är en del av designen. Innehållet (belopp, namn, verifikationsnummer) är påhittat exempeldata.

## Informationsarkitektur

Tre sidor, sju vyer:

| Sida | Vyer |
| --- | --- |
| Böcker | Balansräkning, Resultaträkning, Verifikationer |
| Fakturering och löner | Fakturering, Löner |
| Bokslut | Rapporter, Åtgärder och nyckeltal |

- **Sidor** väljs i headern. Bred skärm (från ungefär 900 px): sidorna ligger som tabbar med en prick där något väntar. Smal skärm: sidtiteln är knappen som fäller ut listan under sig, med sidans status som metarad.
- **Vyer inom en sida** byts på plats: horisontell `scroll-snap`-rad, svep eller prickar. Inget karusellbibliotek. Positionen läses av för att markera rätt prick.
- **Byte av sida** landar alltid på sidans första vy.
- **Chatten hör till vyn**, inte till appen. Varje vy har sin egen tråd med sin egen historik. Byter man vy byter man tråd.

## Skärmar

### Desktop

Två kolumner under en header.

- Header: höjd 62, `border-bottom 1px #e5e7eb`, bakgrund `#fff`, padding 0 20. Vänster: sidtabbar (min-height 44, padding 8/14, radius 9, aktiv `background #f4f4f5` och `color #0a0f1a`, inaktiv transparent och `#52525b`, statusprick 6×6 `#f59e0b`). Höger: vyns status (mono 13), räkenskapsår (mono 13 `#52525b`), agentläge (prick 7×7 + text 13).
- Vänster kolumn (chatten): `flex 1`, `border-right 1px #e5e7eb`. Tråden har padding 26/38, `gap 24`, och är bottenankrad (`justify-content: flex-end`) så det senaste ligger vid inmatningsfältet. Textrader max 54ch. Kort max-bredd 560.
- Höger kolumn (vyn): bredd 470, bakgrund `#fff`. Rubrikrad padding 20/24/14 med vytitel (17/500) och status (mono 12) i vyns statusfärg. Därunder period (mono 12 `#9ca3af`), eventuell banner, sektioner med rader, och en fottext (13, `#6b7280`) som säger vad agenten gör härnäst.
- Inmatningsfältet nederst i chattkolumnen: padding 16/38/20, `border-top 1px #e5e7eb`, fältet radius 12 med streckad kant `#c7c7cc` på `#fbfbfc`. Ren text, inga förslagschips.
- Radernas rytm i vyn: padding 9/8, `border-bottom 1px #f4f4f5`, vänster kolumn titel 14 + metarad mono 11, höger kolumn mono 14 med `font-variant-numeric: tabular-nums`.

Kolumnbredden 470 är fast, chattkolumnen krymper. Under ungefär 1000 px ska vyn läggas över chatten enligt mobilmönstret i stället för att pressas smalare.

### Mobil (390×780 i designen)

- Header 56: sidtiteln är väljaren (min-height 44), prickarna för vyer till höger.
- Vyn överst, chatten nederst, båda synliga samtidigt.
- Chattlisten: knapp min-height 50 som fäller upp och ihop tråden. Öppen tråd 260 px hög med sin egen skroll, därunder textfältet. `box-shadow 0 -8px 20px rgba(10,15,26,0.06)` skiljer listen från vyn.
- Väntar ett beslut syns det som ett märke på listen även när chatten är minimerad.
- Chatten följer med i samma horisontella svep som vyn, så vy och tråd hänger ihop.
- Träffytor aldrig under 44; knappar i kort 46, listen 50.

## De fyra skrivflödena

Varje flöde går hela vägen: väntar → agentens förslag → bekräftelse → pågår → klart och låst, med sitt eget svåra fall. Stegens exakta copy, systembeteende och kanter står i annoteringspanelen i `BokAi flöden v1.dc.html` — läs den, den är specen för flödena.

| Flöde | Sida · vy | Steg | Svårt fall |
| --- | --- | --- | --- |
| Beslutskort | Böcker · Verifikationer | 6 | Postningen misslyckas, perioden låst mitt i |
| Löneunderlag | Fakturering och löner · Löner | 5 | Tidrapport rättas efter godkännandet |
| Kundfaktura | Fakturering och löner · Fakturering | 4 | Bokföring lyckas men sändning fallerar |
| Underlag | Böcker · Verifikationer | 4 | Kvittot skiljer sig från bankhändelsen |

Genomgående regler i alla fyra:

1. **Agenten postar det den är säker på** och lämnar resten som beslut i tråden. Inga notiser, ingen separat inkorg.
2. **Förslag är utkast med id.** Klienten skickar tillbaka id:t vid postning så två tryck inte ger två verifikationer.
3. **Rekommendationer märks men förväljs inte.** Ingenting händer av bara farten.
4. **Konsekvenser står i kortet**, med datum, före trycket — inte i en bekräftelsedialog efteråt.
5. **Optimistiska rader är gråa och tydligt pågående**, med utkastets id, och rullas tillbaka vid fel.
6. **Inget postat ändras.** Rättelse sker som korrigeringsverifikation eller kreditfaktura, via chatten.
7. **Fel formuleras i bokföringstermer** med orsak och konsekvens, i tråden där beslutet togs.
8. **Nästa väntande sak nämns direkt** när något blivit klart, så kön kan arbetas av utan vybyte.

## Tillstånd

Varje vy ska kunna visa sex lägen. Designfilerna visar alla utom tomt läge.

| Läge | Vyn | Chatten | Header |
| --- | --- | --- | --- |
| Normal | rader, ingen banner | tråd med historik | status i `#6b7280` |
| Väntar på dig | banner varning, rad med gul metatext | beslutskort sist i tråden | status i `#b45309` |
| Pågår | rad grå med `postas…`, banner neutral | skriver-indikator | agentläge `Agenten postar`, prick `#2563d9` |
| Klart | ny rad kortvarigt markerad `#f0fdf4` | kvittering med rader och spårchips | status i `#15803d` |
| Fel | rad med röd metatext, banner röd | felkort med försök igen | agentläge `Agenten pausad`, prick `#dc2626` |
| Tomt | sektionen utgår helt, inte tom rubrik | agenten säger att perioden är avstämd | status neutral |

Laddning: vyn visar rader som skelett i `#f4f4f5` med samma radhöjd, aldrig en spinner över hela ytan. Chatten visar tråden så fort den finns; agentens svar strömmar in som text.

## Tillgänglighet

- Kontrast: text mot bakgrund minst 4.5:1. Ljusgrå `#9ca3af` är tillåtet för metadata och kolumnrubriker, aldrig för text som bär en konsekvens.
- Strömmande svar och postningar annonseras via `aria-live="polite"`, inte bara som grå rader.
- Vybyte via svep måste ha tangentbordsekvivalent (piltangenter) och prickarna ska vara riktiga knappar med `aria-label`.
- Beslutskortets primärknapp är aldrig den enda vägen: samma beslut ska gå att uttrycka i text i chattfältet.

## Design tokens

### Färg

| Roll | Värde |
| --- | --- |
| App-bakgrund | `#f4f4f5` |
| Yta | `#fff` · svag `#fafafa` · fält `#fbfbfc` |
| Bläck | `#0a0f1a` |
| Text 2 | `#3f3f46` · dämpad `#52525b` · svag `#6b7280` |
| Metatext | `#9ca3af` |
| Linje | `#e5e7eb` · svag `#f1f1f4` · svagast `#f4f4f5` |
| Kant | `#d4d4d8` · streckad `#c7c7cc` |
| Länk / aktiv | `#2563d9`, hover `#1b49a3` |
| Väntar | yta `#fffbeb`, kant `#fde68a`, text `#92400e`, meta `#b45309`, prick `#f59e0b` |
| Fel | yta `#fef2f2`, kant `#fecaca`, rubrik `#b91c1c`, text `#7f1d1d`, meta `#dc2626` |
| Klart | yta `#f0fdf4`, kant `#bbf7d0`, text `#166534`, meta `#15803d`, prick `#16a34a` |
| Egen bubbla | `#eef0f3` |

Två toner bär betydelse och får inte användas dekorativt: gult betyder att något väntar på människan, grönt att något är postat och låst.

### Typografi

- Geist 300/400/500/600 för allt utom siffror och etiketter.
- Geist Mono 400/500 för belopp, datum, verifikationsnummer, statusrader och versala etiketter (`letter-spacing 0.06–0.08em`, `text-transform: uppercase`).
- Skala: 34 / 21 / 19 / 18 / 17 / 16 / 15 / 14 / 13 / 12 / 11 / 10.
- `letter-spacing -0.02em` på 34, `-0.01em` på 17–21. Radhöjd 1.5–1.65 i löptext, `text-wrap: pretty`.
- Alla belopp `font-variant-numeric: tabular-nums`. Svenskt format: mellanslag som tusentalsavgränsare, minustecken `−` (U+2212).
- Vikt 500 är den tyngsta som används i gränssnittet. Ingen fet text.

### Mått

- Radius: 6, 7, 8, 9, 10, 11, 12, 14, 999. Mobilram 28.
- Spacing: 4-baserad med halvsteg — 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 32, 38, 40, 64.
- Skugga: kort `0 1px 3px rgba(10,15,26,0.06)`, utfälld meny `0 14px 36px rgba(10,15,26,0.16)`, mobil chattlist `0 -8px 20px rgba(10,15,26,0.06)`.
- Fasta mått: desktopheader 62, vykolumn 470, mobilheader 56, mobil chattråd 260.
- Träffytor: minst 44, i mobila kort 46, chattlisten 50.

## Nästa steg i designen

Ritas när desktopflödena är godkända: mobilvarianten av de fyra flödena, tomt läge för nytt bolag, och sidan Bokslut som flöde (den finns som vy men har inget skrivflöde ännu).

## Öppna frågor att svara på innan bygget

1. Hur långt tillbaka ska en vys tråd läsas in, och vad händer med historik över årsskiften?
2. Ska agentläget (arbetar, postar, pausad) vara globalt eller per sida?
3. Vilken tröskel gör en avvikelse till ett beslutskort i stället för ett val — underlagsflödets 120 kr är satt på känsla.
