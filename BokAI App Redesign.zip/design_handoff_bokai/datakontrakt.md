# Datakontrakt

Vad varje vy och varje åtgärd i designen behöver, jämfört med vad som finns i `e9wikner/bok` i dag (läst i `api/routes/`, prefix `/api/v1`).

Kortversionen: **läsvägarna finns i stort sett redan. Skrivflödena finns som agent- och resursanrop men inte som samtal.** Dagens API är byggt för att en agent ska polla en kö och posta färdiga verifikationer, inte för att en människa ska läsa agentens resonemang och svara på det. Det som saknas är konversationen, besluten och idempotensen.

## Finns i repot

### Verifikationer (Böcker)
- `GET /vouchers` — `status=draft|posted|all`, `period_id`, `fiscal_year_id`, `search`, `limit`, `offset`, `sort_by=date|number`, `sort_order`, `exclude_series` (använd `IB` för att dölja ingående balanser).
- `GET /vouchers/{id}`, `GET /vouchers/{id}/audit`, `GET /vouchers/{id}/source-context`.
- `POST /vouchers/{id}/post` — postar utkast. `PUT /vouchers/{id}` — ändrar utkast. `POST /vouchers/{id}/correct`.
- Korrigeringar: `GET /vouchers/{id}/correction-notes`, `POST /vouchers/{id}/correction-draft`, `POST /vouchers/{id}/correction-notes/{note_id}/suggest`, `.../reject`.
- Bilagor: `POST|GET /vouchers/{id}/attachments`, `GET|DELETE /vouchers/{id}/attachments/{attachment_id}`.
- `GET /accounting-corrections` — korrigeringshistorik.

### Rapporter och perioder
- `GET /reports/balance-sheet`, `GET /reports/income-statement`, `GET /reports/general-ledger/{account_code}`, `GET /reports/options`.
- `GET /periods`, `GET /periods/{id}`, `POST /periods/{id}/lock`, `GET /fiscal-years`, `GET /fiscal-years/{id}`.

### Underlag in
- `POST /intake` (uppladdning), `GET /intake/workspace`, `GET /intake/dropzone/status`, `GET /intake/{id}`, `GET /intake/{id}/file`, `PUT /intake/{id}/agent-guidance`, `DELETE /intake/{id}`.
- `POST /bank-inputs`, `GET /bank-inputs/connections`, `GET /bank-inputs/{id}`, `GET /bank-inputs/{id}/file`.

### Fakturering
- `POST /invoices/preview` — beräknar utan att spara. Det här är fakturaförslaget i flöde 3.
- `POST /invoices`, `GET /invoices`, `GET /invoices/{id}`, `POST /invoices/{id}/send`, `POST /invoices/{id}/book`, `POST /invoices/{id}/payment`, `POST /invoices/{id}/credit-note`.
- Utkast: `POST|GET /invoice-drafts`, `GET|PUT /invoice-drafts/{id}`, `POST /invoice-drafts/{id}/send`, `POST /invoice-drafts/{id}/reject`.

### Löner
- `GET /payroll/employees`, `POST /payroll/employees`, `PUT /payroll/employees/{id}`, `PUT /payroll/employees/{id}/salary`.
- `GET /payroll/runs`, `POST /payroll/runs`, `POST /payroll/runs/{id}/generate`, `GET /payroll/runs/{id}/validate`, `GET /payroll/runs/{id}/payslips`, `DELETE /payroll/runs/{id}`.
- `GET /payroll/payslips/{id}`, `POST /payroll/payslips/{id}/mark-sent`, `POST /payroll/payslips/{id}/book`.

### Agentintegration (i dag agentvänd, inte användarvänd)
- `GET /agent/intake/pending` — agentens kö: `voucher_source`, `bank_input`, `correction_note`.
- `POST /agent/vouchers` — agenten skapar verifikation.
- `POST /agent/intake/{source_id}/processing`, `.../failed`.
- `GET /agent/operations/log`.

## Måste byggas

### 1. Tråd per vy
Hela designen står på den. I dag finns ingen konversation någonstans i API:t.

```
GET  /threads/{view_key}?since=<cursor>       → inlägg i ordning, äldst först
POST /threads/{view_key}/messages             → { text, attachments[] }
GET  /threads/{view_key}/stream               → SSE
```

`view_key` är stabil per vy och bolag: `bocker.verifikationer`, `betala.loner`, `betala.fakturering`, `bocker.balans` och så vidare.

Inläggstyper som klienten måste kunna rendera, i samma ordning som de kom: `agent_text`, `user_text`, `user_file`, `decision`, `options`, `draft` (verifikation, faktura, lönekörning), `error`, `receipt`. Varje inlägg bär `id`, `created_at`, `actor` (`agent` eller användarens namn) och valfria `traces[]` (spårchipsen).

Strömmen ska skicka `message.created`, `message.delta`, `message.completed`, och dessutom `view.changed` när en postning ändrat vyns rader — annars måste klienten polla för att hålla siffrorna i takt med tråden.

### 2. Beslut som en förstklassig sak
`GET /agent/intake/pending` är agentens kö och blandar källmaterial med korrigeringsnoteringar. Designen behöver de fall **där agenten avstått**, med agentens egen formulering.

```
GET  /decisions?status=open                   → { id, view_key, kind, title, amount, reason,
                                                 source: {kind, id, date}, age_days, options[] }
POST /decisions/{id}/answer                   → { option_id } eller { free_text }
```

`reason` är agentens text om varför den inte gissade, `options[]` alternativen med `account`, `amount`, `rationale`, `recommended`. Klienten hittar inte på alternativ och räknar inte om belopp.

### 3. Utkast med idempotensnyckel
Designen visar förslag som postas med ett tryck och som aldrig får bli två poster.

- Varje utkast (verifikation, faktura, lönekörning) returnerar ett `draft_id`.
- Postning, sändning och godkännande tar `Idempotency-Key` och svarar med samma resultat vid upprepning.
- Vid konflikt: `409` med den befintliga postens id, så klienten kan visa klart-läget i stället för ett fel.
- Låst period ska ge ett eget fel (`period_locked`) med vem som låste och när, inte ett generellt `500`.

### 4. Lönegodkännande som ett anrop med fyra spår
I dag finns `generate`, `validate`, `mark-sent`, `book` som separata anrop. Designen visar ett godkännande som sätter fyra saker i rörelse och sedan redovisar dem var för sig.

```
POST /payroll/runs/{id}/approve               → { approved_by, approved_at, tracks[] }
GET  /payroll/runs/{id}/status                → tracks[] = { key, state, due_date, amount }
```

`tracks`: `payment_file`, `payslips`, `voucher`, `agi`. Varje spår har eget tillstånd, eftersom betalfilen kan gå igenom medan verifikationen fallerar.

Dessutom behövs brytpunkten: `payment_file.cancellable_until`, så klienten kan sluta erbjuda stopp när det inte längre går.

### 5. Kompletteringar
Underlagsflödet börjar i en lista över postade verifikationer som saknar underlag.

```
GET /vouchers?missing_attachment=true&sort_by=age
```

Verifikationen behöver ett fält för kompletteringsflaggan (satt när den postas utan underlag, borta när ett underlag kopplas) och en ålder i dagar, som driver färgen i vyn.

### 6. Tolkning och matchning av underlag
Flöde 4 steg 3 visar utläst leverantör, datum, belopp och moms mot bankhändelsen.

```
POST /intake/{id}/interpret                   → { vendor, date, amount, vat, confidence,
                                                 match: { voucher_id, diff, hypothesis } }
POST /vouchers/{id}/attachments               → finns, men behöver koppla intake-id, inte bara fil
```

`hypothesis` är agentens förklaring till skillnaden och visas som en hypotes, inte som ett faktum.

### 7. Agentläge
Headern visar arbetar, postar eller pausad. `GET /agent/operations/log` finns, men inte ett läge.

```
GET /agent/status                             → { state, since, current_task, paused_reason }
```

### 8. Sidräknare i ett anrop
Sidtabbarna visar en prick där något väntar, och sidans metarad visar vad. Utan ett aggregat blinkar headern medan fyra anrop landar.

```
GET /overview                                 → per sida: { open_decisions, overdue_invoices,
                                                 payroll_waiting, missing_attachments, period_state }
```

## Fältmappning i vyerna

| Vy | Källa |
| --- | --- |
| Balansräkning | `GET /reports/balance-sheet` |
| Resultaträkning | `GET /reports/income-statement` |
| Verifikationer · postade | `GET /vouchers?status=posted&sort_by=date&sort_order=desc&exclude_series=IB` |
| Verifikationer · väntar | `GET /decisions?status=open` (nytt) |
| Verifikationer · saknar underlag | `GET /vouchers?missing_attachment=true` (nytt) |
| Fakturering · kundfakturor | `GET /invoices` |
| Löner | `GET /payroll/runs`, `GET /payroll/runs/{id}/status` (nytt) |
| Rapporter | `GET /reports/*`, `GET /export/sie4`, `GET /export/pdf` |
| Header · räkenskapsår och periodläge | `GET /fiscal-years`, `GET /periods` |
| Header · agentläge | `GET /agent/status` (nytt) |
| Alla sidors räknare | `GET /overview` (nytt) |

## Regler som hör till kontraktet, inte till klienten

1. **Agenten formulerar.** Motiveringar, hypoteser, felorsaker och rekommendationer kommer från API:t. Klienten skriver inte om dem och hittar inte på egna.
2. **Agenten räknar.** Moms, periodisering, avskrivning och skillnader räknas på servern. Klienten formaterar.
3. **Klienten postar aldrig utan ett utkast-id.** Ingen åtgärd konstrueras i klienten.
4. **Optimistiska rader bär utkastets id** och ersätts av serverns svar, eller rullas tillbaka.
5. **Postat ändras inte.** Rättelse går via korrigeringsverifikation eller kreditfaktura.
